java -jar DeleteHistory.jar
pause